/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TouchableOpacity
} from 'react-native';
import PullToRefreshListViewDemo from './react-native-smart-pull-to-refresh-listview-demo';
import SecondPage from './SecondPage';

export default class FirstPage extends Component {

  _goto = () => {
    console.log(this.props);
    this.props.navigator.push({
      name: 'SecondPageComponent',
      component: SecondPage,
    })
  }

  render() {
    return (
      <View style={styles.container}>
        <TouchableOpacity onPress={this._goto}
          style={{flex:1, alignItems: 'center', justifyContent: 'center'}}
          >
          <Text >PullToRefreshListViewDemo 测试</Text>
          <Text >
            Next Page
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
