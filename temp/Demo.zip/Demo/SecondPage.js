/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TouchableOpacity
} from 'react-native';

import ScrollableTabView from 'react-native-scrollable-tab-view'
import PullToRefreshListViewDemo from './react-native-smart-pull-to-refresh-listview-demo';
import MyListView from './MyListView';

export default class SecondPage extends Component {

  _goto = () => {
    console.log(this.props);
    this.props.navigator.push({
      title: 'MyListView',
      component: MyListView,
    })
  }

  render() {
    return (
      <View style={styles.container}>
        <ScrollableTabView
            tabBarPosition={'bottom'}
        >
          <PullToRefreshListViewDemo tabLabel="PullList" navigator={this.props.navigator}/>
          <MyListView tabLabel="NormalList" navigator={this.props.navigator}/>
        </ScrollableTabView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
