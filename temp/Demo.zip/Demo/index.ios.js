/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Navigator,
  TouchableOpacity
} from 'react-native';

import ScrollableTabView from 'react-native-scrollable-tab-view'
import PullToRefreshListViewDemo from './react-native-smart-pull-to-refresh-listview-demo';
import FirstPage from './FirstPage';
import SecondPage from './SecondPage';

export default class TestScrolling extends Component {
  render() {
    //return (
    //  <ScrollableTabView
    //    tabBarPosition={'bottom'}
    //    >
    //    <First tabLabel="PullList" />
    //    <Second tabLabel="NormalList" />
    //  </ScrollableTabView>
    //);
    return (
        <First tabLabel="PullList" />
    );
  }
}

class First extends Component {
  render() {
     let defaultName = 'FirstPageComponent';
     let defaultComponent = FirstPage;
     return (
     <Navigator
       initialRoute={{ title: defaultName, component: defaultComponent }}
       configureScene={(route) => {
         return Navigator.SceneConfigs.HorizontalSwipeJump;
       }}
       renderScene={(route, navigator) => {
         let Component = route.component;
         return <Component {...route.params} navigator={navigator} />
       }}
       navigationBar={
                      <Navigator.NavigationBar
                        ref={(navigationBar) => {
                          this.navigationBar = navigationBar
                        }}
                        routeMapper={NavigationBarRouteMapper}
                        style={styles.navBar}
                      />
                    }

       />
     );
  }
}

class Second extends Component {
  render() {
     let defaultName = 'SecondPageComponent';
     let defaultComponent = SecondPage;
     return (
     <Navigator
       initialRoute={{ name: defaultName, component: defaultComponent }}
       configureScene={(route) => {
         return Navigator.SceneConfigs.HorizontalSwipeJump;
       }}
       renderScene={(route, navigator) => {
         let Component = route.component;
         return <Component {...route.params} navigator={navigator} />
       }}

       navigationBar={
                      <Navigator.NavigationBar
                        ref={(navigationBar) => {
                          this.navigationBar = navigationBar
                        }}
                        routeMapper={NavigationBarRouteMapper}
                        style={styles.navBar}
                      />
                    }


     />
     );
  }
}

let NavigationBarRouteMapper = {

    LeftButton: function (route, navigator, index, navState) {
        if (index === 0) {
            return null;
        }

        var previousRoute = navState.routeStack[ index - 1 ];
        return (
            <TouchableOpacity
                onPress={() => navigator.pop()}
                style={styles.navBarLeftButton}>
                <Text style={[styles.navBarText, styles.navBarButtonText]}>
                    Back
                </Text>
            </TouchableOpacity>
        );
    },

    RightButton: function (route, navigator, index, navState) {
        //if (index === 0) {
        //  return null;
        //}
        //return (
        //  <TouchableOpacity
        //    onPress={() => navigator.push(newRandomRoute())}
        //    style={styles.navBarRightButton}>
        //    <Text style={[styles.navBarText, styles.navBarButtonText]}>
        //      Next
        //    </Text>
        //  </TouchableOpacity>
        //);
        return null
    },

    Title: function (route, navigator, index, navState) {
        //if (index === 0) {
        //  return null;
        //}
        console.log(`route = `,route)
        return (
            <Text style={[styles.navBarText, styles.navBarTitleText]}>
                {route.title}
            </Text>
        )
        //return (
        //  <TextInput
        //    style={{alignSelf:'center', width: 100, height: 40, borderColor: 'gray', borderWidth: 1}}
        //    defaultValue={route.title + '[' + index + ']'}
        //  />
        //)
    },

};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },

    navigatorBg: {
        backgroundColor: '#F4F4F4',
    },
    navBar: {
        backgroundColor: 'black',
    },
    navBarText: {
        fontSize: 16,
        margin: 10,
        color: 'white',
    },
    navBarTitleText: {
        color: 'white',
        fontWeight: '500',
        marginVertical: 9,
    },
});

AppRegistry.registerComponent('TestScrolling', () => TestScrolling);
